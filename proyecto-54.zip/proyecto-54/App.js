import React, {Component} from 'react';
import {Button, View, Text} from 'react-native';

export default class app extends Component{
  render () {
    return (
  <View>
    <View style ={{marginTop:25}}>
    <Button 
    onPress = {() => alert ('Lucho por la igualdad racial')} 
    title = "Nelson Mandela"
    color ="red"/>
    </View>

    <View style ={{marginTop:25}}>
    <Button 
    onPress = {() => alert ('Fundó la congregación Misioneras de la Caridad')} 
    title = "Madre Teresa"
    color ="orange"/>
    </View>

       <View style ={{marginTop:25}}>
    <Button 
    onPress = {() => alert ('consiguió que la India dejara de ser una colonia británica')} 
    title = "Mahatma Gandhi"
    color ="green"/>
    </View>

       <View style ={{marginTop:25}}>
    <Button 
    onPress = {() => alert ('Matemático británico que en 1822 construyó un modelo de calculadora mecánica o la máquina diferencial')} 
    title = "Charles Babbage"
    color ="blue"/>
    </View>
</View>
    );
  }
}